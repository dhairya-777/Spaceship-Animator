﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ShapeAnimator
{
    internal class Spaceship
    {
        public double X;
        public double Y;
        public double a;
        public double b;    
        public double deltaX = 0;
        public double deltaY = -10;   
        Rectangle spaceS = new Rectangle();
        public void Draw(Canvas canvas)
        {
            spaceS.Width = 10;
            spaceS.Height = 10;
            spaceS.Stroke = Brushes.DarkBlue;
            spaceS.StrokeThickness = 3;
            
            canvas.Children.Add(spaceS);
            X=canvas.ActualWidth/2;
                Y=canvas.ActualHeight -80;    
            Canvas.SetLeft(spaceS, X);
            Canvas.SetTop(spaceS, Y);

        }

        public void Shift(Canvas canvas)
        {
            X += deltaX;
            Y += deltaY;
            Canvas.SetLeft(spaceS, X);
            Canvas.SetTop(spaceS, Y);

            if (X + 10 > canvas.ActualWidth || X - 10  < 0)
            {
                deltaX = -deltaX;
            }
            X = X + deltaX;
            Canvas.SetLeft(spaceS, X);

            if (Y + 20  > canvas.ActualHeight || Y - 10 < 0)
            {
                deltaY = -deltaY;
            }
            Y = Y + deltaY;
            Canvas.SetTop(spaceS, Y);


            // to get spaceship coridnates
             a = Canvas.GetLeft(spaceS);
             b = Canvas.GetTop(spaceS);



        }
        public void Left()
        {
            deltaX = -10;
            deltaY = 0;    
        }
        public void Right()
        {
            deltaX = 10;
            deltaY = 0;
        }
        public void Up()
        {
            deltaX = 0;
            deltaY = -10;
        }
        public void Down()
        {
            deltaX = 0;
            deltaY = 10;
        }

        //public void getPosi(Canvas canvas)
        //{
        //    double a = Canvas.GetLeft(spaceS);
        //    double b = Canvas.GetTop(spaceS);
           

        //}




    }
}
