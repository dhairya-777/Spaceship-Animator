﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ShapeAnimator
{
    internal class Circle
    {
        public Ellipse Ell = new Ellipse();
        public double X;
        public double Y;
        public double Radius;
        public double DeltaX = 1;
        public double DeltaY = 1;

        public Circle(double x, double y, double r)
        {
            X = x; Y = y; Radius = r;
        }
        public void Draw(Canvas canvas)
        {
            Ell.Width = 2 * Radius;
            Ell.Height = 2 * Radius;
            Ell.Stroke = Brushes.Red;
            Ell.StrokeThickness = 2;
            Canvas.SetLeft(Ell, X - Radius);
            Canvas.SetTop(Ell, Y - Radius);
            canvas.Children.Add(Ell);
        }

        public void Shift(Canvas canvas)
        {
            // Flip the direction if it touches canvas of left and right
            if (X + Radius > canvas.ActualWidth || X - Radius < 0)
            {
                DeltaX = -DeltaX;

            }

            if (Y + Radius > canvas.ActualHeight || Y - Radius < 0)
            {
                DeltaY = -DeltaY;

            }
            // updates X posi and refresh screen
            X = X + DeltaX;
            Y = Y + DeltaY;

            Canvas.SetLeft(Ell, X - Radius);
            Canvas.SetTop(Ell, Y - Radius);



        }
        public int i = 0;
        public void Remove(Canvas canvas)
        {
            Console.Beep();
            canvas.Children.Remove(Ell);
            i++;
        }

        // this method will return true if the coordinates are in circle
        public Boolean IsContaining(double x, double y)
        {
            double d = Math.Sqrt((x - X) * (x - X) + (y - Y) * (y - Y));
            return d <= Radius;
        }
    }
}
