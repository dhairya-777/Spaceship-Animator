﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ShapeAnimator
{
    internal class myRectangle
    {

        double X;
        double Y;
        
        Rectangle rec = new Rectangle();
        public double DeltaX = 1;
        public double DeltaY = 1;

        public myRectangle(double x, double y)
        {
            X = x;
            Y = y;
            
        }

        public void Draw(Canvas canvas)
        {
            
            rec.Width = 50;
            rec.Height = 100;
            Canvas.SetLeft(rec, X);
            Canvas.SetTop(rec, Y);

           rec.Stroke = Brushes.Red;
            canvas.Children.Add(rec);
        }

        public void Shift(Canvas canvas)
        {
           

            if (X + 25 > canvas.ActualWidth ||  X - 25 < 0)
            {
                DeltaX = -DeltaX;
            }

            if (Y + 50 > canvas.ActualHeight || Y - 50 < 0)
            {
                DeltaY = -DeltaY;
            }
            X = X + DeltaX;
            Y = Y + DeltaY;

            Canvas.SetLeft(rec, X - 25);
            Canvas.SetTop(rec, Y - 50);


        }
        
        public Boolean IsContaining(double x, double y)
        {
            double d = Math.Sqrt((x - X) * (x - X) + (y - Y) * (y - Y));
            return (d <= 50);
        }

        public void Remove(Canvas canvas)
        {
            canvas.Children.Remove(rec);
        }
    }
}
