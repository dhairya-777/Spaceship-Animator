﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ShapeAnimator
{
    
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }

        bool isFirstClick = true;

        double x1, y1, x2, y2, x3, y3;
        
        public int shapeindex = 0;
        List<Circle> circles = new List<Circle>();
        Spaceship spaceship = new Spaceship(); 
        List<Spaceship> spaceships = new List<Spaceship>();

        List<myRectangle> rectangles = new List<myRectangle>();
        // List<int> deltas = new List<int>();
        Ellipse centerMark;
        Ellipse tempCircle = new Ellipse();

        Rectangle tempRect = new Rectangle();   
        

        private void Button_Rectangle(object sender, RoutedEventArgs e)
        {
            
            shapeindex = 2;
        }

        private void Button_Circle(object sender, RoutedEventArgs e)
        {
            shapeindex = 1;

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            spaceship.Draw(ShapeCanvas);
            
            spaceships.Add(spaceship);  
            //touchesToShape();
            DispatcherTimer sstimer = new DispatcherTimer();
            sstimer.Interval = TimeSpan.FromMilliseconds(500);
            sstimer.Tick += SStimer_tick;
            sstimer.Start();

        }
        public void SStimer_tick(object sender, EventArgs e)
        {
            spaceship.Shift(ShapeCanvas);

        }

        private void Window_KeyUp(object sender, KeyEventArgs e)
        {

            switch (e.Key.ToString())
            {
                case "Left":
                    spaceship.Left();
                    break;
                case "Right":
                    spaceship.Right();
                    break;
                case "Up":
                    spaceship.Up();
                    break;
                case "Down":
                    spaceship.Down();
                    break;

                default:
                    break;

            }

        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
         
            Shift();
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(5);
            timer.Tick += timer_tick;
            timer.Start();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
           Gamestart();
            DispatcherTimer timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(5);
            timer.Tick += gtimer_tick;
            timer.Start();
        }
        public void Gamestart()
        {
            double a1 = spaceship.a;
            double a2 = spaceship.b;
            
            
            // here if spaceship's coordinates are in circle then it will die
            foreach (Circle c in circles)
            {
                if (c.IsContaining(a1, a2))
                {
                    c.Remove(ShapeCanvas);
                   
                }
            }
            
            // I tried rectangle just for fun and working littlebit
            foreach (myRectangle r in rectangles)
            {
                if (r.IsContaining(a1, a2))
                {
                    r.Remove(ShapeCanvas);
                }
            }

        }
        public void gtimer_tick(object sender, EventArgs e)
        {
            
            Gamestart();
        }
        public void timer_tick(object sender, EventArgs e)
        {
            Shift(); 
        }

        public void Shift()
        {
            foreach (Circle c in circles)
            {
                c.Shift(ShapeCanvas);
               
                    
            
                

            }
            foreach (myRectangle r in rectangles)
            {
                r.Shift(ShapeCanvas);

            }



        }
        
        





        private void ShapeCanvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (shapeindex == 1)
            { 
            if (isFirstClick)
            {
                // This is the first click
                // This is the CENTER coordinates (NOT the TOPLEFT)
                x1 = e.GetPosition(this).X;
                y1 = e.GetPosition(this).Y;

                centerMark = new Ellipse();
                centerMark.Width = 4;
                centerMark.Height = 4;
                centerMark.Stroke = Brushes.Red;
                ShapeCanvas.Children.Add(centerMark);
                Canvas.SetLeft(centerMark, x1 - 2);
                Canvas.SetTop(centerMark, y1 - 2);

                ShapeCanvas.Children.Add(tempCircle);
            }
            else
            {
                // THis is the second click
                double x2 = e.GetPosition(this).X;
                double y2 = e.GetPosition(this).Y;

                double radius = Math.Sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));


                Circle c = new Circle(x1, y1, radius);
                c.Draw(ShapeCanvas);
                circles.Add(c);

                

                // Remove the temp geometry
                ShapeCanvas.Children.Remove(tempCircle);
                ShapeCanvas.Children.Remove(centerMark);
            }

            isFirstClick = !isFirstClick;
        }
            
                if (shapeindex == 2)   // for Rectangle
                {
                    x1 = e.GetPosition(this).X;
                    y1 = e.GetPosition(this).Y;

        
                    myRectangle r = new myRectangle(x1, y1);
                    r.Draw(ShapeCanvas);
                    rectangles.Add(r);

                    


                
                
                  

                }
            
    }

        private void ShapeCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (isFirstClick)
            {
                return;
            }

            x3 = e.GetPosition(this).X;
            y3 = e.GetPosition(this).Y;

            double radius = Math.Sqrt((x3 - x1) * (x3 - x1) + (y3 - y1) * (y3 - y1));


            tempCircle.Width = radius * 2;
            tempCircle.Height = radius * 2;
            tempCircle.Stroke = Brushes.Red;
            Canvas.SetLeft(tempCircle, x1 - radius);
            Canvas.SetTop(tempCircle, y1 - radius);

        }

    }
}
